#pragma once
class MetodoBurbuja
{
public:
	MetodoBurbuja();
	~MetodoBurbuja();
};

