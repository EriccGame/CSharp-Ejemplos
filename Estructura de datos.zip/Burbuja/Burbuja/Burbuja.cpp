// Burbuja.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include "conio.h"
#include "stdio.h"
#include "stdlib.h"
#include "MetodoBurbuja.cpp"

using namespace std;

int main()
{
	MetodoBurbuja mb;

	mb.iValores[0] = 55;
	mb.iValores[1] = 45;
	mb.iValores[2] = 23;
	mb.iValores[3] = 3;
	mb.iValores[4] = 78;
	mb.iValores[5] = 255;
	mb.iValores[6] = 8;
	mb.iValores[7] = 15;
	mb.iValores[8] = 19;
	mb.iValores[9] = 41;

	mb.ordenarMetodoBurbuja();

	for (int i = 0; i < 10; i++)
	{
		printf("%i ", mb.iValores[i]);
	}

	getchar();

    return 0;
}

