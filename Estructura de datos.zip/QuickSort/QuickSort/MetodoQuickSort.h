#pragma once
class MetodoQuickSort
{
public:
	MetodoQuickSort();
	~MetodoQuickSort();
};

