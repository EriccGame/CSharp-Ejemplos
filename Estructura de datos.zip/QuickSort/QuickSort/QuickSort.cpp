// QuickSort.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include "conio.h"
#include "stdio.h"
#include "stdlib.h"
#include "MetodoQuickSort.cpp"

using namespace std;

int main()
{
	MetodoQuickSort mqs;

	mqs.iValores[0] = 55;
	mqs.iValores[1] = 45;
	mqs.iValores[2] = 23;
	mqs.iValores[3] = 3;
	mqs.iValores[4] = 78;
	mqs.iValores[5] = 255;
	mqs.iValores[6] = 8;
	mqs.iValores[7] = 15;
	mqs.iValores[8] = 19;
	mqs.iValores[9] = 41;

	mqs.ordenarMetodoBurbuja();

	for (int i = 0; i < 10; i++)
	{
		printf("%i ", mqs.iValores[i]);
	}

	getchar();

	return 0;
}
