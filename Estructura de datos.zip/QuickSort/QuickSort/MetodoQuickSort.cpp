#include "stdafx.h"

class MetodoQuickSort
{
public:
	int iValores[10];

	void ordenarMetodoBurbuja()
	{
		bool bBandera = true;
		int iAux;

		for (int i = 1; (i < 10) && bBandera; i++)
		{
		    bBandera = false;
		    for (int j = 0; j < 9; j++)
		    {
		        if (iValores[j + 1] > iValores[j])
		        {
		            iAux = iValores[j];
					iValores[j] = iValores[j + 1];
					iValores[j + 1] = iAux;
		            bBandera = true;
		        }
		    }
		}
	}
};