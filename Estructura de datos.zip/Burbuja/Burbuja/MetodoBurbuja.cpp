#include "stdafx.h"

class MetodoBurbuja
{
public:
	int iValores[10];

	void ordenarMetodoBurbuja()
	{
		int temp = 0;

		for (int i = 0; i < 10; i++) 
		{
			for (int k = 0; k < 10 - 1; k++) 
			{
				if (iValores[k] > iValores[k + 1])
				{
					temp = iValores[k + 1];
					iValores[k + 1] = iValores[k];
					iValores[k] = temp;
				}
			}
		}
	}
};